import java.util.Arrays;

public class One_Dimensional_Array_6
{
	public static void main(String[] args)
	{
		int[] arr = new int[] {1, 4, 34, 56, 7};
		Arrays.sort(arr);
		System.out.println(Arrays.toString(arr));
	}
}