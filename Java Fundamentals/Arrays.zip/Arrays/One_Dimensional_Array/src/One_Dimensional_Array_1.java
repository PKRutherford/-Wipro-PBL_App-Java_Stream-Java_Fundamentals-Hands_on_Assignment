import java.util.Scanner;
public class One_Dimensional_Array_1
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		int j=1,i,sum=0;
		double avg;
		System.out.println("Enter Number Of Elements You Want:- ");
		int n = sc.nextInt();
		int[] arr = new int[n];
		
		for(i=0;i<n;i++)
		{
			System.out.println("Enter "+j+" Element :- ");
			arr[i] = sc.nextInt();
			j++;
		}
		for(i=0;i<n;i++)
		{
			sum=sum+arr[i];
		}
		avg=(double)sum/arr.length;
		System.out.println("The sum of array :- "+sum);
		System.out.println("The avg of array :- "+avg);
	}
}