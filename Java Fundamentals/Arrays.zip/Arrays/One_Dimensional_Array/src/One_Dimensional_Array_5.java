import java.util.Scanner;
public class One_Dimensional_Array_5
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		int j=1,i,k,temp;
		System.out.println("Enter Number Of Elements You Want:- ");
		int n = sc.nextInt();
		int[] arr = new int[n];
		for(i=0;i<n;i++)
		{
			System.out.println("Enter "+j+" Element :- ");
			arr[i] = sc.nextInt();
			j++;
		}
		for(i=0;i<n;i++)
		{
			for(k=i+1;k<n;k++)
			{
				if(arr[i]<arr[k])
				{
					temp=arr[i];
					arr[i]=arr[k];
					arr[k]=temp;
				}
			}
		}
		System.out.println("The Two Maximum Numbers are "+arr[0]+" & "+arr[1]);
		System.out.println("The Two Minimum Numbers are "+arr[n-2]+" & "+arr[n-1]);
	
	}
}