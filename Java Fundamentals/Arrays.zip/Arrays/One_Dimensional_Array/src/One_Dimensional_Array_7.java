import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
public class One_Dimensional_Array_7
{
	public static void main(String[] args)
		{
			int[] arr = {12,34,12,45,67,89};
			List<Integer> arr1 =new ArrayList<>();
			for(int item : arr)
			{
				if(!arr1.contains(item))
				{
					arr1.add(item);
				}
			}
			System.out.println(Arrays.toString(arr1.toArray()));
		}
}