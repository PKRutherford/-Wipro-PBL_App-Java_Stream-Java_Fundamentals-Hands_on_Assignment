import java.util.Scanner;
public class One_Dimensional_Array_3
{
	public static void main(String[] args)
	{
		int a=0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter The Search Element :- ");
		int n = sc.nextInt();
		int[] arr = new int[] {1,4,34,56,7};
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]==n)
			{
				System.out.println(i);
			}
			else
			{
				a++;
				if(a==arr.length)
				System.out.println("-1");
			}
			
		}
		
	}
}