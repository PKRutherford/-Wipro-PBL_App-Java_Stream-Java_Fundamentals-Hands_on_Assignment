import java.util.Scanner;
public class One_Dimensional_Array_2
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		int j=1,i;
		System.out.println("Enter Number Of Elements You Want:- ");
		int n = sc.nextInt();
		int[] arr = new int[n];
		for(i=0;i<n;i++)
		{
			System.out.println("Enter "+j+" Element :- ");
			arr[i] = sc.nextInt();
			j++;
		}
		int max = arr[0];
		int min = arr[0];
		for(i=0;i<n;i++)
		{
			if(arr[i]>max)
			{
				max=arr[i];
			}
			else if(arr[i]<min)
			{
				min=arr[i];
			}
		}
		System.out.println("Maximum Number is :- "+max);
		System.out.println("Minimum Number is :- "+min);
	}
}