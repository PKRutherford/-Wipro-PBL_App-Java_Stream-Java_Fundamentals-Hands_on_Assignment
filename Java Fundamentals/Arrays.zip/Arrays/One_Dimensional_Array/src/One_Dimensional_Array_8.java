import java.util.Scanner;
public class One_Dimensional_Array_8
{
	public static void main(String[] args)
		{
			int i,j=1,k, sixpos = -1, sevenpos = -1,sum=0,add=0,c=0;
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter Number Of Elements You Want:- ");
			int n = sc.nextInt();
			int[] arr = new int[n];
			for(i=0;i<n;i++)
			{
				System.out.println("Enter "+j+" Element :- ");
				arr[i] = sc.nextInt();
				j++;
			}
			for(i=0;i<n;i++)
			{
				if(arr[i]==6)
				{
					sixpos=i;
					//System.out.print(sixpos+"  ");
				}
				else if(arr[i]==7)
				{
					sevenpos=i;
					//System.out.print(sevenpos+"  ");
				}
			}
			if(sevenpos>sixpos)
			{
				for(i=0;i<sixpos;i++)
				{
					sum=sum+arr[i];
				}
				for(i=arr.length-1;i>sevenpos;i--)
				{
					add=add+arr[i];
				}
				k=add+sum;
				System.out.println(k);
			}
			else if(sevenpos<sixpos)
			{
				for(i=0;i<arr.length;i++)
				{
					c = c+arr[i];
				}
				System.out.print(c);
			}
		}
}