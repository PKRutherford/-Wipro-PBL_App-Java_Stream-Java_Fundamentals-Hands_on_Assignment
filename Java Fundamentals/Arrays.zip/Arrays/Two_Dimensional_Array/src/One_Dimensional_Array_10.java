public class One_Dimensional_Array_10
{
	public static void main(String[] args)
		{
			if(args.length!=9)
			{
				System.out.println("Please enter 9 integer numbers");
				System.exit(0);
			}
			int i,j;
			int [][] arr = new int[3][3];
			int x=0;
			int max = 0;
			for(i=0;i<arr.length;i++)
			{
				for(j=0;j<arr.length;j++)
				{
					arr[i][j] = Integer.parseInt(args[x++]);
				}
			}
			System.out.println("The given array is : ");
			for(i=0;i<1;i++)
			{
				for(j=0;j<3;j++)
				{
					System.out.print(arr[i][j]+" ");
				}
			}
			for(i=1;i<2;i++)
			{
				System.out.print("\n");
				for(j=0;j<3;j++)
				{
					System.out.print(arr[i][j]+" ");
				}
			}
			for(i=2;i<3;i++)
			{
				System.out.print("\n");
				for(j=0;j<3;j++)
				{
					System.out.print(arr[i][j]+" ");
				}
			}
			for(i=0;i<3;i++)
			{
				for(j=0;j<3;j++)
				{
					if(arr[i][j]>max)
					{
						max=arr[i][j];
					}
				}
			}
			System.out.println("\nThe biggest number in the given array is : "+max);
		}
}