public class One_Dimensional_Array_9
{
	public static void main(String[] args)
		{
			if(args.length!=4)
			{
				System.out.println("Please enter 4 integer numbers");
				System.exit(0);
			}
			int i,j;
			int [][] arr = new int[2][2];
			int x=0;
			for(i=0;i<arr.length;i++)
			{
				for(j=0;j<arr.length;j++)
				{
					arr[i][j] = Integer.parseInt(args[x++]);
				}
			}
			System.out.println("The given array is : ");
			for(i=0;i<1;i++)
			{
				for(j=0;j<2;j++)
				{
					System.out.print(arr[i][j]+" ");
				}
			}
			for(i=1;i<2;i++)
			{
				System.out.print("\n");
				for(j=0;j<2;j++)
				{
					System.out.print(arr[i][j]+" ");
				}
			}
			System.out.println("\nThe reverse of the array is : ");
			for(i=1;i>=1;i--)
			{
				for(j=1;j>=0;j--)
				{
					System.out.print(arr[i][j]+" ");
				}
			}
			for(i=0;i>=0;i--)
			{
				System.out.print("\n");
				for(j=1;j>=0;j--)
				{
					System.out.print(arr[i][j]+" ");
				}
			}
		}
}